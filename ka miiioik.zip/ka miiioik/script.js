function searchContent() {
  const input = document.getElementById('searchInput').value.toLowerCase();
  if (input.includes('book') || input.includes('study')) {
    alert('Search Result: Find your textbooks and learning materials!');
  } else {
    alert('No results found.');
  }
}

const advices = [
  "Stay consistent in studying.",
  "Practice makes perfect.",
  "Never give up on tough subjects.",
  // Add more up to 50 advices
];

function showAdvice() {
  const randomIndex = Math.floor(Math.random() * advices.length);
  document.getElementById('adviceText').innerText = advices[randomIndex];
}
function signUpWithGoogle() {
  alert('Redirecting to Google sign-up...');
  window.location.href = 'success.html'; // After fake sign-up
}

function registerUser(event) {
  event.preventDefault();
  alert('Registration Successful!');
  window.location.href = 'success.html';
}function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}function downloadSuccess() {
  alert('Downloaded!');
}
// script.js

function showDownloadMessage(event) {
  const msg = document.getElementById("downloadMessage");
  msg.style.color = "orange";
  msg.textContent = "Downloading...";

  // Show "Downloaded" after 2 seconds
  setTimeout(() => {
    msg.style.color = "green";
    msg.textContent = "Downloaded";
  }, 2000);
}